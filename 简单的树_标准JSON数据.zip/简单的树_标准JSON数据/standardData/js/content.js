var setting = {
				edit: {
					enable: true,
					showRemoveBtn: false,
					showRenameBtn: false
				},
				data: {
					simpleData: {
						enable: true
					}
				},
				callback: {
					beforeClick: beforeClick,
					onClick: onClick,
					beforeDrag: beforeDrag,
					beforeDrop: beforeDrop
				}
			};
			
var zNodes = [
				{ name:"父节点1 - 展开", open:true,
					children:[
						{
							name:"父节点11 - 折叠",
							children:[
								{ name:"叶子节点111"},
								{ name:"叶子节点112"},
								{ name:"叶子节点113"},
								{ name:"叶子节点114"}
							]
						},
						{
							name:"父节点12 - 折叠",
							children: [
								{ name:"叶子节点121"},
								{ name:"叶子节点122"},
								{ name:"叶子节点123"},
								{ name:"叶子节点124"}
							]
						},
						{ 
							name:"父节点13 - 没有子节点", isParent:true
						}
					]
				},
				{  name:"父节点2 - 折叠",
					 children:[
					 	{
					 		name:"父节点21 - 展开", open:true,
					 		children:[
					 			{ name:"叶子节点211"},
								{ name:"叶子节点212"},
								{ name:"叶子节点213"},
								{ name:"叶子节点214"}
					 		]
					 	},{
					 		 name:"父节点22 - 折叠",
					 		 children: [
								{ name:"叶子节点221"},
								{ name:"叶子节点222"},
								{ name:"叶子节点223"},
								{ name:"叶子节点224"}
							]
					 	},{
					 		name:"父节点23 - 折叠",
					 		children: [
								{ name:"叶子节点231"},
								{ name:"叶子节点232"},
								{ name:"叶子节点233"},
								{ name:"叶子节点234"}
							]
					 	}
					 ]
				},
				{ name:"父节点3 - 没有子节点", isParent:true }
			];
			
var className = "dark";
var clickFlag = 0 ;
var Tree1, Tree2;
var strs={};

function beforeDrag(treeId, treeNodes) {
	for (var i=0,l=treeNodes.length; i<l; i++) {
		if (treeNodes[i].drag === false) {
			return false;
		}
	}
	return true;
}

function beforeDrop(treeId, treeNodes, targetNode, moveType) {
	return targetNode ? targetNode.drop !== false : true;
}

function beforeClick(treeId, treeNode, clickFlag) {
	className = (className === "dark" ? "":"dark");
	return (treeNode.click != false);
}

function onClick(event, treeId, treeNode, clickFlag) {
	
}

$(document).ready(function(){
	Tree1 = $.fn.zTree.init($("#treeDemo"), setting, zNodes);
	Tree2 = $.fn.zTree.init($("#treeDemo2"), setting,null);
});

function addNodes(){
	moveTreeNode(Tree1, Tree2);
}

function moveTreeNode(zTree1, zTree2){
	var nodes = zTree1.getSelectedNodes();
	for(var i=0;i<nodes.length;i++){
		var node = nodes[i];
		strs.id =node.id;
		
	}
}



